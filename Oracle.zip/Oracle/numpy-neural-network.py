import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

class SimpleNeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.01):
        """
        Initialize the neural network architecture.
        
        I'm using He initialization because I read it works well for ReLU activations.
        The weights are initialized with some randomness to break symmetry.
        """
        # Random seed for reproducibility (a trick I learned to make experiments consistent)
        np.random.seed(42)
        
        # Layer dimensions
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # Learning rate (I'm starting with a small value to avoid overshooting)
        self.learning_rate = learning_rate
        
        # Initialize weights and biases
        # Using He initialization for ReLU (multiplying by sqrt(2/n))
        self.W1 = np.random.randn(self.input_size, self.hidden_size) * np.sqrt(2/self.input_size)
        self.b1 = np.zeros((1, self.hidden_size))
        
        self.W2 = np.random.randn(self.hidden_size, self.output_size) * np.sqrt(2/self.hidden_size)
        self.b2 = np.zeros((1, self.output_size))
    
    def relu(self, x):
        """
        ReLU activation function.
        I chose ReLU because it helps prevent vanishing gradient problem.
        """
        return np.maximum(0, x)
    
    def relu_derivative(self, x):
        """
        Derivative of ReLU for backpropagation.
        This is crucial for gradient calculation during training.
        """
        return x > 0
    
    def softmax(self, x):
        """
        Softmax activation for output layer.
        Helps convert raw scores to probability distribution.
        """
        # Subtract max for numerical stability (a trick I learned to prevent overflow)
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def forward(self, X):
        """
        Forward propagation through the network.
        This is where inputs are transformed through layers.
        """
        # Hidden layer
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = self.relu(self.z1)
        
        # Output layer
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.output = self.softmax(self.z2)
        
        return self.output
    
    def one_hot_encode(self, Y, num_classes):
        """
        Convert class labels to one-hot encoded format.
        This helps in calculating cross-entropy loss.
        """
        return np.eye(num_classes)[Y]
    
    def cross_entropy_loss(self, Y_true, Y_pred):
        """
        Cross-entropy loss calculation.
        A standard loss function for classification problems.
        """
        m = Y_true.shape[0]
        # Clipping to prevent log(0)
        Y_pred = np.clip(Y_pred, 1e-15, 1 - 1e-15)
        return -np.sum(Y_true * np.log(Y_pred)) / m
    
    def backward(self, X, Y):
        """
        Backpropagation to calculate gradients and update weights.
        This is the heart of neural network learning.
        """
        m = X.shape[0]
        
        # One-hot encode the labels
        Y_one_hot = self.one_hot_encode(Y, self.output_size)
        
        # Compute gradients
        dZ2 = self.output - Y_one_hot
        dW2 = np.dot(self.a1.T, dZ2) / m
        db2 = np.sum(dZ2, axis=0, keepdims=True) / m
        
        dA1 = np.dot(dZ2, self.W2.T)
        dZ1 = dA1 * self.relu_derivative(self.z1)
        dW1 = np.dot(X.T, dZ1) / m
        db1 = np.sum(dZ1, axis=0, keepdims=True) / m
        
        # Update weights and biases
        self.W2 -= self.learning_rate * dW2
        self.b2 -= self.learning_rate * db2
        
        self.W1 -= self.learning_rate * dW1
        self.b1 -= self.learning_rate * db1
    
    def train(self, X, Y, epochs=1000, verbose=True):
        """
        Training loop with optional progress tracking.
        """
        for epoch in range(epochs):
            # Forward propagation
            output = self.forward(X)
            
            # Compute loss
            loss = self.cross_entropy_loss(self.one_hot_encode(Y, self.output_size), output)
            
            # Backpropagation
            self.backward(X, Y)
            
            # Print progress periodically
            if verbose and epoch % 100 == 0:
                print(f"Epoch {epoch}, Loss: {loss}")
        
        return loss
    
    def predict(self, X):
        """
        Make predictions using the trained network.
        """
        output = self.forward(X)
        return np.argmax(output, axis=1)

# Let's use the Iris dataset as an example
def main():
    # Load and prepare the Iris dataset
    iris = load_iris()
    X, y = iris.data, iris.target
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize features
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Initialize and train the network
    # I'm experimenting with network architecture
    nn = SimpleNeuralNetwork(
        input_size=4,  # 4 features in Iris dataset
        hidden_size=8,  # trying different hidden layer sizes
        output_size=3,  # 3 classes in Iris
        learning_rate=0.1
    )
    
    # Train the network
    nn.train(X_train, y_train, epochs=1000, verbose=True)
    
    # Make predictions
    y_pred = nn.predict(X_test)
    
    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\nModel Accuracy: {accuracy * 100:.2f}%")


main()

# Some reflections on this implementation:
# 1. This is a simple neural network and might not be as performant as more advanced libraries
# 2. The hyperparameters (learning rate, hidden layer size) are crucial and might need tuning
# 3. I've used some tricks like He initialization and numerical stability in softmax
# 4. This is a learning project - there's always room for improvement!
